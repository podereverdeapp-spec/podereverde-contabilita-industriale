# Contabilità Industriale — Stato del Progetto
_Documento di riferimento — aggiornato ad ogni decisione importante. Se stai leggendo questo per riprendere il progetto da zero (nuova chat), leggi tutto prima di scrivere codice: contiene decisioni di business non ovvie dal solo codice._

## 1. Architettura

- **Repo GitHub**: podereverde-contabilita-industriale (separato da podereverdeapp)
- **Deploy**: Vercel, progetto separato
- **Database**: STESSO Supabase di Podere Verde App/podereverdeapp.it (pyjymnpnxatqwfhguaus) — non un database a parte
  - Motivo: `ci_report_uba_animale.animale_id`, `ci_costo_animale_annuale.animale_id/lotto_id`, `ci_report_acquisto_animali.animale_id/lotto_id` sono FK dirette verso `animali`/`lotti_suini` — niente sincronizzazione, dati in tempo reale
  - **Flusso a senso unico verso podereverdeapp.it**: Contabilità Industriale calcola e scrive (`ci_costo_animale_annuale`), podereverdeapp.it legge soltanto (tab "💰 Costi" nella scheda animale, aggiunta in allevamento v94 — vedi sezione 18)
- **Ispirazione iniziale**: "Prima App" di Colabucci (Next.js+Prisma, database separato) — analisi del codice sorgente reale fatta a fondo (sezione 19), non solo dalle pagine web
- **Lettura PDF fatture**: funzione server `api/leggi-fattura-pdf.js`, chiama Claude (chiave `ANTHROPIC_API_KEY` su Vercel, mai esposta al browser). **Bug noto irrisolto**: pagamento Anthropic Console bloccato per carte europee (Stripe SetupIntent 0€ + 3DS) — la lettura PDF non è mai stata testata con successo per questo motivo.
- **Stack tecnico**: React + Vite, Supabase diretto (`@supabase/supabase-js`), niente ORM. Libreria `xlsx` per import/export Excel.

## 2. Schema database (tabelle, prefisso `ci_`)

- `ci_fornitori`, `ci_clienti` — anagrafiche
- `ci_fatture`, `ci_articoli_fattura` — fatture (ATTIVA/PASSIVA) e righe, con classificazione a 4 livelli (Area/Centro di Costo/Destinazione/Tipo di costo)
- `ci_cespiti`, `ci_cespiti_ammortamento` — cespiti gestiti in app, con `fattura_id` (collegamento alla fattura di provenienza, NULL per i cespiti storici migrati) e `specie` (array, l'Imputazione)
- `ci_piano_dei_conti` — combinazioni valide Area × Centro di Costo
- `ci_regole_fornitore_variabile` (FCV, parola chiave), `ci_regole_fornitore_fissa` (FCF, fissa per fornitore)
- `ci_report_acquisto_animali` — righe da tradurre a mano in podereverdeapp.it (include quantità/unità_misura/prezzo_unitario)
- `ci_righe_scartate` — memoria righe da ignorare per fornitore+descrizione (persiste tra caricamenti)
- `ci_bozze_import` — bozza di importazione non ancora salvata (autosalvata ogni 1,5s)
- `ci_parametri` — soglie di business configurabili da UI (sezione 9)
- `ci_costo_animale_annuale` — costo calcolato per animale/unità di lotto, anno per anno (sezione 8) — **unica tabella scritta qui e letta da podereverdeapp.it**
- `ci_tasso_uba_annuale` — tasso €/UBA-giorno salvato per anno (trasparenza/debug)
- `ci_residuo_riproduttore`, `ci_scarico_riproduttore_annuale` — meccanismo riproduttori (sezione 10)
- **Tutte le tabelle hanno RLS disattivato** (`ALTER TABLE ... DISABLE ROW LEVEL SECURITY`) — se una nuova tabella creata in futuro dà errore "row-level security policy", è quasi sempre perché questa riga è stata dimenticata nello script di creazione.
- **Policy aggiunta su tabelle di podereverdeapp.it** (non di Contabilità Industriale): `animali`, `lotti_suini`, `suini_lotto` avevano RLS che permetteva lettura solo ad utenti autenticati — Contabilità Industriale si connette come `anon` (nessun login), quindi leggeva 0 righe senza errore. Aggiunta una policy `FOR SELECT TO anon USING (true)` che si somma a quelle esistenti, senza toccare scrittura/autenticazione di podereverdeapp.it.

## 3. Classificazione a 4 livelli — LE REGOLE DI BUSINESS (fondamentali, non modificare senza motivo)

**AREA** (17 voci): Allevamento, Coltivazione, Lavoro, Energia Elettrica, Acqua, Consulenze, Assicurazioni,
Lavorazioni prodotti allevamento, Spese Promozionali, Oneri Finanziari, Varie, Animali non d'allevamento,
Orto, Canoni ed Abbonamenti, **Ammortamenti** (speciale), **ACQUISTO ANIMALI** (speciale), **TRASPORTO ANIMALI** (speciale)

**CENTRO DI COSTO**: a cascata sull'Area, espandibile dall'operatore (se scrive uno nuovo, si aggiunge al piano dei conti per il futuro — con controllo case-insensitive per non duplicare varianti dello stesso nome)

**DESTINAZIONE**: Bovini/Suini/Ovini/Generali(→ripartiti per UBA-giorno)/Pollame/Cavalli

**TIPO DI COSTO**: Fisso / Variabile / **Ammortizzabile** (quote di ammortamento — vincolo DB: Area="Ammortamenti" ⟹ Tipo="Ammortizzabile", sempre, non derogabile)

### Le 3 aree speciali

- **Ammortamenti**: NON è un costo ordinario — genera un **Cespite** automaticamente al salvataggio della riga (mappatura: descrizione riga→descrizione bene, Categoria Ammortamento→categoria, fornitore→fornitore, **fattura→fattura_id** (collegamento per tracciabilità), data fattura→data acquisto, imponibile→costo acquisto, %Ammortamento→anni=arrotonda(100/%), Imputazione→specie). **Bug storico trovato e corretto (v33)**: prima si salvava solo il dettaglio di classificazione, mai il Cespite vero e proprio — corretto, ora la creazione è automatica.
  - **Imputazione (tendina)**: Bovini, Suini, Ovini, Generali, **Cavalli, Pollame, Orto** (aggiunte in una sessione successiva), Nessuno
  - **Categoria Ammortamento — le 10 voci esatte (tendina, non testo libero)**: 3 - Attrezzatura specifica; 3 - Costruzioni leggere; 5 - Macchinari, apparecchi e attrezzature varie; 5 b - Macchinari, apparecchi e attrezzature varie extra allevamento; 6 - Spese atti notarili; 7 - Animali non oggetto di allevamento; 15 - Autovetture, motoveicoli e simili; 30 – Avviamento; 31 - Spese di costituzione e trasformazione; 34 - Altri oneri pluriennali
- **ACQUISTO ANIMALI**: "finta area" — non entra MAI nella contabilità industriale ordinaria (niente Centro Costo/Destinazione/Tipo Costo). Va in `ci_report_acquisto_animali` (stato DA_ELABORARE), che l'operatore umano traduce a mano in un animale o lotto su podereverdeapp.it.
  - **Specie (tendina)**: Bovini, Suini, Ovini, "Piu' specie acquistate insieme"
  - **Razza (tendina a cascata sulla specie)**: Bovini→Chianina/Marchigiana/Maremmana/Limousine/Charolais/Frisona/Pezzata Rossa/Meticcia/Altra; Suini→Large White/Landrace/Duroc/Cinta senese/Mora romagnola/Nero casertano/Nero apucalabro/Meticcia/Altra; Ovini→Sopravvissana/Suffolk/Meticcia/Altra
- **TRASPORTO ANIMALI**: SEMPRE manuale, mai auto-classificabile da FCV/FCF. Natura mista: una fattura può contenere sia trasporto verso il macello (resta in contabilità industriale ordinaria) sia trasporto di animali in ingresso (va nel Report Acquisto Animali). L'operatore divide l'imponibile tra le due caselle; il sistema verifica che la somma torni all'imponibile originale della riga.

## 4. Piano dei Conti — Area × Centro di Costo (dati reali caricati)

16 aree con centri di costo definiti (elenco completo caricato in `ci_piano_dei_conti`): Allevamento, Coltivazione, Lavoro, Energia Elettrica, Acqua, Consulenze, Assicurazioni, Lavorazioni prodotti allevamento, Spese Promozionali, Oneri Finanziari, Varie, Orto, Canoni ed Abbonamenti, TRASPORTO ANIMALI, più **Animali non d'allevamento** (aggiunta successivamente: Mangime e alimentazione/Veterinaria e cure/Attrezzature e manutenzione/Altro — copre Pollame e Cavalli). Ammortamenti e ACQUISTO ANIMALI non hanno centro di costo proprio (usano rispettivamente Categoria Ammortamento e Specie/Razza/Destinazione).

## 5. Motore di classificazione automatica (costruito e testato)

`src/motoreClassificazione.js` — ordine di applicazione:
1. Cerca regola fissa (FCF) per il fornitore (per P.IVA se nota, altrimenti nome case-insensitive) → se trovata, applica sempre
2. Altrimenti cerca regola variabile (FCV): fornitore + parola chiave contenuta nella descrizione
3. Altrimenti → stato MASCHERA (classificazione manuale richiesta)
4. Regole trasversali non derogabili: Area=Ammortamenti forza Tipo=Ammortizzabile; Area=TRASPORTO ANIMALI forza sempre MASCHERA

**Dati reali caricati**: 60 fornitori, 249 regole FCV, 11 regole FCF (Alfa Omega ha solo FCF).

**Sistema "che impara"**: quando una riga MASCHERA viene classificata a mano e salvata, l'operatore può scegliere: solo questa volta / regola fissa per il fornitore (FCF) / regola per parola chiave (FCV).

**Salvataggio per riga singola**: ogni riga si salva individualmente (`salvaRiga`), condividendo la fattura con altre righe già salvate. `annullaSalvataggioRiga` elimina i record creati (articolo/dettaglio ammortamento/cespite/report acquisto/regola) e ricalcola i totali fattura.

**Righe scartate con memoria**: pulsante "🗑️ Scarta e ricorda" salva in `ci_righe_scartate` (fornitore+descrizione); ai caricamenti successivi le righe dello stesso fornitore+descrizione compaiono già marcate.

**Unità di misura**: campo libero (nessun vincolo), accetta qualunque testo dalla fattura originale.

## 6. Motore di calcolo costi (`motoreUba.js`, `motoreRiproduttori.js`, `calcoloReportCosti.js`)

### 6.1 Motore UBA (`motoreUba.js`)
Identico a quello di podereverdeapp.it (`ExportManager.jsx`), calcolato **direttamente dagli animali/lotti reali**, nessun import Excel intermedio:
- `UBA_FASCE_EXP`: coefficienti per specie/fascia d'età (bovino: 0.40/0.70/1.00 a 210/730/∞ giorni; suino: 0.027/0.30/0.50 a 90/365/∞ giorni; ovino: 0.027/0.10/0.15 a 120/365/∞ giorni)
- `periodoNellAnnoExp`, `calcolaUBAMedioExp`, `categoriaContabileExp` — stessa logica di ExportManager.jsx (vedi sezione 19 per i dettagli trovati nel codice sorgente)
- `calcolaReportUba(animali, lotti, suiniLotto, anno)`: righe UBA per un anno, sia per animali individuali sia per unità di lotto suini non individualizzate

### 6.2 Formula "aggressiva" costo/UBA-giorno — DECISIONE FINALE (Filippo, non la formula semplice di podereverdeapp.it)
```
F(t)_produttivi = UBA-giorni SOLO di produttivi+riproduttori (esclusi improduttivi_usciti)
netto_da_recuperare = C(t) - V(t)
tasso_RETTIFICATO = netto_da_recuperare / F(t)_produttivi   ← usato per allocare, punto
```
Escludere gli improduttivi dal divisore realizza GIÀ da solo la ridistribuzione — **non si aggiunge nessuna "perdita" sopra** (bug di doppio conteggio trovato e corretto in fase di test: farlo genera euro dal nulla). Per trasparenza si mostra anche `tasso_semplice` (se si dividesse su tutti) e `perdita_spalmata` come dato informativo, mai sommato al calcolo.

**Correzione di fondo (non solo interfaccia)**: i costi **diretti** a una specie (Destinazione/Imputazione = quella specie) restano DENTRO quella specie — solo i costi **Generali** si ripartiscono proporzionalmente agli UBA-giorni produttivi di ciascuna specie. Ogni specie mostra un'**incidenza €/UBA-giorno propria** (non un tasso aziendale unico) — emergono differenze reali tra specie. Funzione condivisa `calcolaRigaAggregata(costiDiretti, ubaGiorniProduttiviPerSpecie, ubaGiorniProduttiviAziendali)` in `motoreUba.js`, riusata a ogni livello di granularità (aziendale, area, centro di costo).

### 6.3 Pollame, Cavalli, Orto — MAI ripartiti sulle 3 specie d'allevamento
Diversi dai costi "Generali": Pollame/Cavalli (Destinazione) e Orto (Area) sono attività collaterali, **esclusi sia dai costi diretti sia dai Generali**. Riconosciuti sia per Destinazione sia per Area (per "Animali non d'allevamento", entrambi i criteri — vedi sezione 7). Mostrati in un riquadro rosso a parte con l'incidenza calcolata sul totale UBA-giorni degli animali d'allevamento veri, come dato di confronto (non un costo allocato).

## 7. Ammortamenti — distinzione Generali vs "non imputabile in allevamento"

**Regola definitiva**: tra le Imputazioni possibili per un cespite (Bovini/Suini/Ovini/Generali/Nessuno/Cavalli/Pollame/Orto):
- **Generali** → SI ripartisce pro-quota su Bovini/Suini/Ovini in base agli UBA-giorni
- **Nessuno, Cavalli, Pollame, Orto** → MAI ripartiti su nessuna specie d'allevamento, né direttamente né via Generali — sempre esclusi ed evidenziati **in rosso** con l'etichetta "non imputabile in allevamento"

La logica di calcolo condivisa (`calcoloReportCosti.js`) gestiva già correttamente questa distinzione quando è stata scritta; il buco reale era altrove: le tendine Imputazione non offrivano ancora Cavalli/Pollame/Orto come opzioni (corretto), e Report Cespiti aveva un elenco di chiavi incompleto per cui quei cespiti sparivano senza traccia dalla scomposizione "per Imputazione" (corretto — ora appaiono evidenziati in rosso con l'etichetta, sia in Report Cespiti sia nella scheda del singolo cespite in Gestione).

**Attenzione per il futuro**: quando si tocca questa logica, verificare SEMPRE che un nuovo valore di Imputazione non finisca per errore nel bucket "Generale" (che si ripartisce) invece che nel bucket "non imputabile" (che resta escluso) — è la classe di bug più probabile qui.

## 8. Costo per animale — `ci_costo_animale_annuale`

Ogni animale, in proporzione ai suoi UBA-giorni, si prende in carico sia i costi ordinari (Fisso/Variabile) sia la quota di ammortamento dell'anno — stesso meccanismo di ripartizione per entrambi. Copre sia l'animale individuale (`animale_id`) sia l'unità di lotto non individualizzata (`lotto_id`+`unita_nr`) — stesso meccanismo, non un secondo sistema a parte.

**Traghettamento costi all'assegnazione BDN**: quando un suinetto passa da unità di lotto anonima ad animale individuale con BDN (pulsante "🏷️ Assegna BDN" in podereverdeapp.it), tutti i costi già maturati mentre era nel lotto devono traghettare sul nuovo `animale_id` — non ripartire da zero. **Non ancora costruito** (requisito registrato, da implementare).

**Flusso di calcolo (ordine d'uso corretto in Report Costi)**: 1) Report UBA per l'anno → 2) Report Costi per l'anno (calcola e salva `ci_costo_animale_annuale` + `ci_tasso_uba_annuale`) → 3) Report Riproduttori per lo stesso anno (calcola e scarica sui figli, aggiorna la riga di costo già salvata al punto 2).

## 9. Parametri configurabili (`ci_parametri`, pagina Parametri)

Tutte le soglie di business sono leggibili/modificabili da UI, non hardcoded:
- Soglia parti per consolidamento femmine riproduttrici (default: 3, uguale per tutte le specie)
- Soglia anni di attività riproduttiva per consolidamento maschi, per specie (Bovini: 3, Suini: 2, Ovini: 2)
- Vita produttiva attesa per riproduttore, per specie (valore iniziale impostato da Filippo, poi da affinare nel tempo — meccanismo di auto-affinamento non ancora costruito)
- Età minima (default: >3 anni) per includere un animale nel calcolo del peso medio storico per la stima del valore di realizzo riproduttori

## 10. Riproduttori — meccanismo completo (`motoreRiproduttori.js`, pagina Report Riproduttori)

**Perché**: la ripartizione costi ordinaria (UBA-giorni) resta uguale per tutti. In più, il costo di UN riproduttore si scarica sui SUOI figli, non resta a carico generico dell'azienda.

**Residuo da recuperare**:
```
Residuo = (Costo di acquisto, se presente + Costi di crescita pre-riproduttiva) − Valore di realizzo stimato
```
Ammortizzato sulla vita produttiva attesa; ogni anno la quota si somma al mantenimento ordinario e si scarica sui figli dell'anno.

**Conto sospeso**: se un anno non ha figli, la quota si accumula (il residuo NON si riduce, perché nessuno l'ha effettivamente recuperata) — alla prima cucciolata successiva si scarica quota corrente + tutto l'arretrato insieme, diviso tra i figli di quell'anno. **Bug trovato e corretto in fase di test**: il residuo rimanente si riduceva solo della quota dell'anno, non dell'intero importo scaricato (quota + arretrato) — corretto, verificato che dopo N anni il residuo torni esattamente a zero.

**Valore di realizzo stimato — 2 valutazioni indipendenti** (non derivate l'una dall'altra, altrimenti collassano matematicamente allo stesso numero — bug trovato prima di costruire, richiesto un campo `prezzo_kg_carcassa` separato su `prezzi_riforma` di podereverdeapp.it):
- Peso vivo medio storico (animali stessa specie/razza usciti con >3 anni di vita) × `prezzo_kg_vivo`
- Peso carcassa medio storico (stesso filtro) × `prezzo_kg_carcassa`
- Alla creazione del residuo si usa prudenzialmente la valutazione più bassa tra le due (non si sa ancora se uscirà vivo o macellato)

**Consolidamento dati personali**:
- Femmine: sotto 3 parti → media di specie/razza; da 3 parti in poi → dato personale (Prolificità = nati vivi÷parti; IIP = media giorni tra parti)
- Maschi: nessuna stima di prolificità necessaria, solo conteggio figli reali (via `padre_id`). Consolidato dopo N anni di attività (Bovini 3, Suini 2, Ovini 2); prima, media di specie/razza

**Meccanismo ricorsivo, di generazione in generazione**: il costo di nascita ereditato si accumula anno per anno; all'uscita dell'animale, il conto prende una di 3 strade — (1) uscita produttiva: si chiude, compensato da V(t); (2) diventa riproduttore: il suo conto accumulato diventa il residuo per i SUOI figli; (3) uscita improduttiva: si spalma sugli altri vivi (formula aggressiva).

**Conguaglio finale** (pulsante "⚖️ Applica conguagli"): quando il riproduttore esce davvero, si conosce il valore REALE (peso effettivo alla sua uscita, non più la media storica). La differenza tra reale e stimato si scarica come conguaglio sui figli dell'**ultimo anno soltanto** (quello di uscita), positivo o negativo. Se non ci sono figli quell'anno, resta un dato aziendale generico. Testato con casi realistici (valore superiore/inferiore alla stima, nessun figlio nell'anno).

## 11. Cespiti — Gestione e Report (sezione unificata, due viste)

"Cespiti" è un'unica voce di menu con due pulsanti interni: **Gestione** (elenco, modifica, elimina, genera quote) e **Report** (riepiloghi, piano futuro).

**Gestione**: i cespiti sono raggruppati per **categoria**, ognuna con una fascia colorata (colore diverso a rotazione) che mostra valore storico complessivo, quota di ammortamento dell'anno corrente, fondo ammortamento accumulato. Sotto ogni fascia, i cespiti di quella categoria in ordine alfabetico, consultabili (click per espandere → piano ammortamento), modificabili (categoria/imputazione/coefficiente/data/fornitore, con conferma prima di salvare), ed eliminabili (pulsante 🗑️, con conferma — cancella a cascata anche le quote collegate). Le imputazioni "non imputabile in allevamento" (Nessuno/Cavalli/Pollame/Orto) sono evidenziate in rosso con etichetta, sia in vista compatta sia espansa.

**Report**: riepilogo generale, scomposizione per Categoria e per Imputazione (con evidenziazione rossa per le non-allevamento), e **piano di ammortamento atteso per i prossimi 5 anni**.

**Problema reale trovato da Filippo (duplicati)**: dopo il fix v33 (creazione automatica del Cespite da riga Ammortamenti), risalvare in Carica Fatture una riga già salvata PRIMA di quel fix poteva creare un secondo Cespite duplicato per lo stesso bene. Query diagnostica fornita (`diagnosi_duplicati_cespiti.sql`, cerca cespiti con stessa descrizione+data+costo, e cespiti multipli collegati alla stessa fattura). **Da rilanciare periodicamente se si sospettano nuovi duplicati.**

## 12. Report Costi — struttura a più livelli (sezione unificata, 7 viste)

"Report Costi" è un'unica voce di menu con sfondi colorati diversi per livello:
1. **Aggregato (aziendale)** — un tasso unico per tutta l'azienda, allocazione per specie
2. **Per Area** — una riga per Area, con Imponibile complessivo, €/UBA-gg aziendale, e scomposizione Bovini/Suini/Ovini (costo allocato + incidenza specifica)
3. **Per Area e Centro di Costo** — stessa struttura, con drill-down per Centro di Costo (Categoria Ammortamento per gli Ammortamenti)
4. **Storico — Generale/Bovini/Suini/Ovini** (4 viste): confronto tra l'anno scelto e i 3 precedenti + media dei 4, stessa struttura a due parti (Area sopra, Centro di Costo sotto) per ciascuna

**Motore condiviso**: `calcoloReportCosti.js` estrae la logica comune (`calcolaDatiPerArea`, `calcolaDatiPerAreaCentro`), riusata sia dai report a un anno sia da quelli storici — nessuna duplicazione tra i due.

L'anno si sceglie una volta sola in alto (condiviso tra Aggregato/Per Area/Per Area e Centro); le viste Storiche gestiscono i propri 4 anni internamente.

## 13. Articoli & Prezzi

Allineato alla struttura reale di Prima App (verificata nel codice sorgente, sezione 19): raggruppa per **prodotto normalizzato** (non fornitore+prodotto — così lo stesso mangime da fornitori diversi si confronta in un'unica riga), fornitore/cliente come filtro applicabile, copre sia acquisti sia vendite. Colonne: prezzo minimo/medio/massimo/più recente, **scostamento % dalla media** (rosso se sopra, verde se sotto — cliccabile per aprire un grafico lineare SVG dell'andamento nel tempo con la media tratteggiata), evidenziazione rossa quando il prezzo recente eguaglia/supera il massimo di tutti gli acquisti precedenti.

## 14. Ricerca

Ricerca testuale trasversale su numero fattura, fornitore/cliente, descrizione articoli, note — filtri combinabili per Tipo (acquisto/vendita), Area, Specie/Destinazione, Anno, periodo date, range importo. Click su un risultato apre la stessa ricomposizione fattura usata in Fatture Passive/Attive.

## 15. Esportazione Excel (tutte le pagine)

Utilità condivisa `esportaExcel.js` (usa la libreria `xlsx`, già presente per l'import) — pulsante "📥 Esporta Excel" presente su tutte le 14+ pagine dell'app. Ogni file scaricato porta la data del giorno nel nome. `numeroExcel()` normalizza i numeri prima di scriverli (arrotondamento, niente stringhe).

## 16. Formattazione numeri (tutta l'app)

Formato italiano ovunque: punto per le migliaia, virgola per i decimali (`formattaNumero`/`formattaEuro` in `parsingUtils.js`, usa `toLocaleString("it-IT", {useGrouping:true})` — **attenzione**: senza `useGrouping:true` esplicito, i numeri a 4 cifre non venivano raggruppati correttamente, bug trovato in fase di test).

## 17. Layout app

Menu laterale verticale a sinistra (non più orizzontale in alto) — più comodo con 14 voci. Sezioni con più viste interne (Report Costi, Cespiti) usano pulsanti di navigazione secondaria con sfondi colorati distinti per orientarsi.

## 18. Collegamento con podereverdeapp.it (in corso, sessione condivisa)

**Costo di acquisto — campo condiviso, scrivibile da entrambi i programmi (decisione presa)**: a differenza di `ci_costo_animale_annuale` (a senso unico), il costo di acquisto (`animali.prezzo_acquisto`, con estremi fattura) resta **un solo campo condiviso** sulla stessa riga della stessa tabella — puoi inserirlo sia da podereverdeapp.it sia dalla Contabilità Industriale, non sono due dati da sincronizzare. **Fatto**: alert rosso "⚠️ Manca costo acquisto" quando `provenienza==="Acquistato"` e `prezzo_acquisto` mancante — badge nella card lista animali, banner prominente nella scheda dettaglio (podereverdeapp.it v96), e riquadro con l'elenco completo in Report Acquisto Animali (Contabilità Industriale). **Da fare**: la finestra di inserimento diretto del costo da Report Acquisto Animali (Filippo l'ha esplicitamente rimandata a un secondo momento, "che poi struttureremo").

**Flusso deciso**: Contabilità Industriale calcola e scrive `ci_costo_animale_annuale`; podereverdeapp.it legge soltanto, mai scrive.

**Fatto (podereverdeapp.it v94)**: nuova tab "💰 Costi" nella scheda completa di ogni animale (accanto a Info/Genealogia/Eventi, in `allevamento_app.jsx`, componente `Anagrafica`) — mostra lo storico anno per anno (UBA-giorni, categoria, mantenimento, nascita ereditata, scaricato sui figli, totale) + il totale cumulato, letti in sola lettura da `ci_costo_animale_annuale` filtrando per `animale_id`. Verificato nel codice che "Costo netto residuo" esisteva PRIMA solo nell'export Excel (`ExportManager.jsx`/`UBAReport.jsx`), nessuna vista a schermo — ora c'è.

**Da fare**: la stessa vista per i **componenti di lotto** (suinetti senza BDN individuale, riferiti a `lotto_id`+`unita_nr` invece che `animale_id`) — oggi la tab Costi funziona solo per animali con BDN individuale.

**Nota tecnica importante sull'ambiente di lavoro**: il codice sorgente di podereverdeapp.it (cartella `allevamento`) è stato analizzato a fondo in sessioni precedenti di questa stessa conversazione — i file erano già disponibili nell'ambiente sandbox senza bisogno di ricaricamento, fino a quando l'ambiente non si è resettato (evento imprevisto, non collegato a nulla fatto dall'utente). **Se l'ambiente risulta vuoto in una nuova sessione**: i pacchetti consegnati (`allevamento_v94.tar.gz` più recente) restano scaricabili e vanno richiesti/ricaricati da Filippo se non recuperabili da `/mnt/user-data/outputs/`.

## 19. Analisi del codice sorgente reale di Prima App (riferimento, confronto diretto)

**Confermato**: il sistema AREA/CENTRO DI COSTO/DESTINAZIONE/TIPO DI COSTO con regole FCV/FCF **non esiste nel codice reale di Prima App** — era un progetto di integrazione mai realizzato lì (proposto in un pacchetto di specifica tecnica per Colabucci, mai implementato). Quello costruito qui va oltre Prima App su questo punto.

**Articoli & Prezzi reale**: pagina `src/app/(main)/articoli/page.tsx`, API `GET /api/articoli` + `GET /api/articoli/storico-prezzi`. Raggruppa per `nomeProdottoNorm` (normalizzato e salvato una volta all'inserimento, non ricalcolato). Statistiche: conteggio, prezzo min/max/medio, ultimo prezzo, quantità totale, capi totali, ultima data. Copre sia fatture attive sia passive.

**Cespiti reale**: modello `Cespite` (Prisma) — `descrizione`, `categoria` (stringa libera), `fornitoreId`, `dataAcquisto`, `costoAcquisto`, `anniAmmortamento` (default 5), `specie` (array `SpecieAnimale`: BOVINI/OVINI/SUINI/GALLINE/MATERIALI/GENERALE/CAVALLI). Quote costanti = costoAcquisto/anniAmmortamento, generate fino a esaurimento. Import Excel ammortamenti da foglio "Matrice categoria x specie" — confermato compatibile col nostro Libro Cespiti.

**Motore UBA reale, in podereverdeapp.it `ExportManager.jsx`** (non in Prima App — Prima App usa `ripartizione-uba.ts` con formula SEMPLICE, diversa dalla nostra "aggressiva" per scelta esplicita di Filippo): `UBA_FASCE_EXP`, `periodoNellAnnoExp`, `calcolaUBAMedioExp`, `categoriaContabileExp` — funzioni reali, non ricostruite a memoria.

**Classificazione PRODUTTIVO/IMPRODUTTIVO_USCITO — funzione reale** (`categoriaContabileExp` in ExportManager.jsx):
```js
function categoriaContabileExp(animale) {
  if (animale.stato === "attivo") return animale.riproduttore ? "riproduttore" : "produttivo";
  const motivo = (animale.motivo_uscita||"").toLowerCase();
  const isProduttivo = MOTIVI_PRODUTTIVI_EXP.some(k => motivo.includes(k));
  if (isProduttivo) return animale.riproduttore ? "riproduttore" : "produttivo";
  return "improduttivo_uscito";
}
```
con `MOTIVI_PRODUTTIVI_EXP = ["macellazione","macellato","venduto","riformato","riforma","vendita"]` (sottostringa, non uguaglianza esatta). Qualunque motivo che non contiene una di queste parole (anche "Altro", "Morto", "Predato") è IMPRODUTTIVO_USCITO.

**"Riporto quota UBA"**: se un animale presente nel report UBA dell'anno precedente non compare nel nuovo import, si riporta l'ultima quota nota, a meno che non sia uscito per macellazione/decesso. Meccanismo di Prima App — probabilmente non più necessario dato che ora l'UBA si calcola direttamente dagli animali reali ogni volta, non da un import storico.

## 20. Problemi noti / da monitorare

- Pagamento Anthropic Console bloccato per carte europee — lettura PDF fatture mai testata con successo
- Il browser di Filippo a volte traduce automaticamente la pagina, storpiando i nomi delle voci — disattivare la traduzione automatica per il sito
- **Report generali** e completamento **componenti di lotto** in podereverdeapp.it: ancora da fare (vedi sezioni 18 e task aperti)
- Traghettamento costi all'assegnazione BDN (sezione 8): requisito registrato, non ancora implementato
